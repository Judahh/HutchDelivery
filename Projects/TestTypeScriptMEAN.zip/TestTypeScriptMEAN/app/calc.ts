export class Calculadora {
	somar(a:number, b:number)  {
		return a + b;
	}
}

