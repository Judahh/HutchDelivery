'use strict';

angular.module('mean.i18n').factory('I18n', [
  function() {
    return {
      name: 'i18n'
    };
  }
]);
