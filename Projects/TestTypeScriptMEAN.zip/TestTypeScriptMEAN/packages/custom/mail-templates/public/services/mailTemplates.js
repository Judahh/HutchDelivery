'use strict';

angular.module('mean.mail-templates').factory('MailTemplates', [
  function() {
    return {
      name: 'mail-templates'
    };
  }
]);
