Mongoose models go here
