README: meanUser
